from django.http import HttpRequest, HttpResponse
from django.shortcuts import render

def home(request: HttpRequest) -> HttpResponse:
    if request.method == "GET":
        msg: str = "Welcome To Task-List"
        return render(request, "base.html", {"message": msg})

