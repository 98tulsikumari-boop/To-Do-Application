from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import render, get_object_or_404
from django.db.models import QuerySet 
from .models import Task
from django.template.loader import render_to_string

def task_list(request: HttpRequest) -> HttpResponse:
    tasks: QuerySet = Task.objects.all()
    return render(request, "main/add_task.html", {"tasks": tasks})

def add_task(request: HttpRequest):
    if request.method == "POST":
        task_name: str = request.POST.get("task_name")
        task_description: str = request.POST.get("task_description")

        if task_name:
            if not Task.objects.filter(name=task_name).exists():
                Task.objects.create(name=task_name, description=task_description)
                # Update list after saving new task
                tasks: QuerySet = Task.objects.all()
                # TypeError: Object of type QuerySet is not JSON serializable
                html_string: str = render_to_string("main/task_rows.html", {"tasks": tasks})
                return JsonResponse({
                    "tasks": html_string,
                    "message": "Task added successfully"}, status=201) 

            else:
                return JsonResponse({
                    "message": "Task already exists!"}, status=400)

        else:
            return JsonResponse({
                "success": True,
                "message": "Task name should be provided"}, status=400)

    return render(request, "main/add_task.html")               # HttpResponse

def edit_task(request: HttpRequest, id: int):
    if request.method == "POST":
        task_name = request.POST.get("task_name")
        task_description = request.POST.get("task_description")

        if not Task.objects.filter(name=task_name).exclude(id=id).exists():
            task = Task.objects.get(id=id)
            task.name = task_name
            task.description = task_description
            task.save()
            tasks: QuerySet = Task.objects.all()
            html_string = render_to_string("main/task_rows.html", {"tasks": tasks})
            return JsonResponse({
                "tasks": html_string,
                "message": "Task updated successfully!"}, status=201)

def delete_task(request: HttpRequest, task_id=None):
    if request.method == "POST":
        task = get_object_or_404(Task, pk=task_id)
        task.delete()

        tasks: QuerySet = Task.objects.all()
        html_string = render_to_string("main/task_rows.html", {"tasks": tasks})
        return JsonResponse({
            "tasks": html_string,
            "message": "Task deleted successfully!"}, status=201)

def toggle_complete(request: HttpRequest, task_id=None) -> HttpResponse:        # "toggle" refers to a function or control that switches between two possible states or option, such as "on" and "off" or "visible" or "hidden".
    if request.method == "POST":
        task = get_object_or_404(Task, pk=task_id)
        task.completed = True
        task.save()

        # Updating the taskList
        tasks: QuerySet = Task.objects.all()
        html_string = render_to_string("main/task_rows.html", {"tasks": tasks})
        return JsonResponse({
            "tasks": html_string,
            "message": "Your task has marked as completed!"
        })

    


    
    
            

            
                
                

