$(document).ready(function (){
    console.log("Ajax is ready");

    $("#btnRegister").click(function (event) {
        event.preventDefault();

        const task_id = $("#task_id").val();
        const task_name = $("#task_name").val();
        const task_description = $("#task_description").val();
        const csrfToken = $("input[name='csrfmiddlewaretoken']").val();

        console.log(`Task Name: ${task_name} Description: ${task_description}`);

        $.ajax({
            url: task_id ? `/task/edit/${task_id}/` : `/task/add/`,
            method: "POST",
            data: {
                task_id: task_id,
                task_name: task_name,
                task_description: task_description,
                csrfmiddlewaretoken: csrfToken
            },
            success: function (response) {
                $("#task_id").val("");
                $("#task_name").val("");
                $("#task_description").val("");
                $("#btnRegister").text("Add");

                $("#acknowledge").text(response.message)
                    .css("color", "green")
                    .fadeIn().delay(3000).fadeOut();

                $("#taskList").html(response.tasks)
            },
            error: function (error) {
                const errorMsg = error.responseJSON?.message || "An error occur";
                $("#acknowledge").text(errorMsg)
                    .css("color", "red")
                    .fadeIn().delay(3000).fadeOut();
            }
        });
    });

    $(document).on('click', '.edit-btn', function(event){
        event.preventDefault();

        const task_id = $(this).data('id');
        const task_name = $(this).data('name');
        const task_description = $(this).data('description');
        
        console.log(`Task ID: ${task_id} Task Name: ${task_name} Description: ${task_description}`);

        $("#task_id").val(task_id);
        $("#task_name").val(task_name);
        $("#task_description").val(task_description);
        $("#btnRegister").text('Update');
    });

    $(document).on('click', '.delete-btn', function(event){
        event.preventDefault();

        const task_id = $(this).data('id');
        const csrfToken = $("input[name='csrfmiddlewaretoken']").val();

        if(!confirm("Are you sure to delete this task?"))
            return;

        $.ajax({
            url: `/task/delete/${task_id}/`,
            method: "POST",
            data: {
                csrfmiddlewaretoken: csrfToken
            },
            success: function (response) {
                $("#acknowledge").text(response.message)
                    .css("color", "green")
                    .fadeIn().delay(3000).fadeOut();

                $("#taskList").html(response.tasks)
            },
            error: function(error) {
                $("#acknowledge").text("Failed to delete the task")
                    .css("color", "red")
                    .fadeIn().delay(3000).fadeOut();
            }
        });
    });

    $(document).on('click', '.complete-btn', function (event){
        event.preventDefault();

        const task_id = $(this).data('id');
        const csrfToken = $("input[name='csrfmiddlewaretoken']").val();

        // Check if task has already completed.
        if ($(this).hasClass('btn-success')) {
            alert("You have already completed this task.");
            return;
        }

        // When i will click first time.
        if(!confirm("You are going to mark as completed")) {
            return;
        }
            

        $.ajax({
            url: `/task/complete/${task_id}`,
            method: "POST",
            data: {
                csrfmiddlewaretoken: csrfToken
            },
            success: function (response) {
                $("#acknowledge").text(response.message)
                    .css("color", "green")
                    .fadeIn().delay(3000).fadeOut();

                $("#taskList").html(response.tasks)
            },
            error: function(error) {
                $("#acknowledge").text("An error occur!")
                    .css("color", "red")
                    .fadeIn().delay(3000).fadeOut();
            }
        });
    });
});